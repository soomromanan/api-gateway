package com.FAJIG.microservices.limitsservicedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimitsServiceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimitsServiceDemoApplication.class, args);
	}

}
