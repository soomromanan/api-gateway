package com.FAJIG.microservices.limitsservicedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimitsServiceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
